package com.mblinn.mbfpp.oo.fi

//import com.mblinn.mbfpp.oo.fi.person.PersonExample.Person
import org.junit.runner.RunWith
import org.scalatest.matchers.ShouldMatchers
import org.scalatest.FunSpec
import org.scalatest.junit.JUnitRunner
/*
@RunWith(classOf[JUnitRunner])
class PersonExampleSpec extends FunSpec with ShouldMatchers {
  describe("person sorting") {
    it("should return an empty sequence when passed an empty sequence.") {
      val people = Vector[Person]()
      people.sortWith(
        (p1: Person, p2: Person) => p1.firstName < p2.firstName) should equal(Vector[Person]())

    }
    it("should sort people by first name.") {
      val p1 = Person("Michael", "Bevilacqua")
      val p2 = Person("Pedro", "Vasquez")
      val p3 = Person("Robert", "Aarons")
      val people = Vector(p3, p2, p1)
      val sortedPeople = Vector(p1, p2, p3)
      
      people.sortWith(
        (p1: Person, p2: Person) => p1.firstName < p2.firstName) should equal(sortedPeople)
    }
  }
}*/