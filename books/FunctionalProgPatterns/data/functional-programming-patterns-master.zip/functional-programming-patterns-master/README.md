functional-programming-patterns
===============================

- Source Code for  Functional Programming Patterns in Scala and Clojure Book 
- Unmodified source code can be found here: http://pragprog.com/titles/mbfpp/source_code
