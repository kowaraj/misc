(ns mbfpp.oo.javabean.person)

(def p 
  {:first-name "John"
   :middle-name "Quincy"
   :last-name "Adams"})
