(ns mbfpp.oo.tinyweb.intro)

(count [1 2 3 4])

(.length "Clojure")